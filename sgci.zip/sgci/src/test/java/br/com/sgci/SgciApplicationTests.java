package br.com.sgci;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgciApplicationTests {

	@Test
	void contextLoads() {
	}

}
