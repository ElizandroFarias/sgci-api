package br.com.sgci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgciApplication {

	public static void main(String[] args) {
		SpringApplication.run(SgciApplication.class, args);
	}

}
